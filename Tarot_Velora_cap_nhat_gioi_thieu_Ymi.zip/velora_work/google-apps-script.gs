/** TAROT VELORA — Google Apps Script endpoint
 * 1) Tạo Google Sheet mới, đặt tên sheet đầu tiên là Bookings.
 * 2) Extensions > Apps Script, dán toàn bộ mã này.
 * 3) Deploy > New deployment > Web app; Execute as: Me; Who has access: Anyone.
 * 4) Copy Web app URL, dán vào GOOGLE_SHEETS_WEB_APP_URL trong app.js.
 * Sheet chỉ nên được chia sẻ riêng với tài khoản quản lý; không công khai bảng tính.
 */
function doPost(e) {
  const data = JSON.parse(e.postData.contents);
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sh = ss.getSheetByName('Bookings') || ss.insertSheet('Bookings');
  if (sh.getLastRow() === 0) sh.appendRow(['Mã booking','Thời gian gửi','Tên khách','Instagram','Điện thoại','Reader','Ngày xem','Giờ xem','Dịch vụ','Tổng tiền','Ghi chú','Trạng thái']);
  sh.appendRow([data.id || '', new Date(), data.name || '', data.instagram || '', data.phone || '', data.reader || '', data.date || '', data.time || '', (data.services || []).map(s => s.name + ' (' + s.price + 'đ)').join('; '), data.total || 0, data.note || '', 'Chờ duyệt']);
  return ContentService.createTextOutput(JSON.stringify({ok:true})).setMimeType(ContentService.MimeType.JSON);
}
