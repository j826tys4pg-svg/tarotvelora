TAROT VELORA — WEBSITE UPDATE

GIAO DIỆN ĐÃ CẬP NHẬT
- Giữ thương hiệu TAROT VELORA, logo và tông ivory/milk cream, caramel, champagne gold, lavender nhẹ.
- Font Cormorant Garamond cho tiêu đề; DM Sans cho nội dung.
- Trang chủ, giới thiệu thương hiệu, 4 hồ sơ reader, khu vực Ymi nổi bật, quy trình trải nghiệm, feedback placeholder (không tự tạo đánh giá giả), bảng giá, booking, FAQ và liên hệ.
- Booking chọn reader/ngày/giờ/dịch vụ, tự tính tổng.
- admin.html có bộ lọc reader/ngày/trạng thái, cập nhật trạng thái demo và xuất CSV.
- Responsive cho điện thoại và máy tính.

READER VÀ GIÁ
- Nhím, Ymi, Bycatkj, Pisk.
- Phụ thu đang giữ theo bản trước: Nhím +25.000đ; Ymi +65.000đ; Bycatkj +25.000đ; Pisk +25.000đ.
- Giá dịch vụ gốc giữ nguyên theo bản trước trong app.js. Có thể chỉnh trực tiếp mảng readers và services nếu cần.

CÁCH THAY TRÊN WEBSITE NETLIFY MÀ GIỮ NGUYÊN LINK
1. Giải nén file TAROT_VELORA_Website_Final.zip trên máy tính. Bên trong phải thấy trực tiếp index.html, app.js, style.css, admin.html, google-apps-script.gs và thư mục assets.
2. Đăng nhập Netlify bằng tài khoản đang quản lý website tarotvelora.netlify.app.
3. Mở đúng site có tên/địa chỉ tarotvelora.netlify.app (không bấm Add new site, không tạo site mới).
4. Vào Deploys của đúng site đó.
5. Tại khu vực deploy thủ công / drag and drop, tải lên thư mục đã giải nén (hoặc ZIP nếu giao diện Netlify cho phép chọn ZIP). Nội dung deploy phải có index.html ở ngay thư mục gốc, không nằm trong một thư mục con lồng thêm.
6. Chờ deploy hoàn tất rồi mở lại tarotvelora.netlify.app. Nếu điện thoại vẫn hiện bản cũ, tải lại trang hoặc mở tab ẩn danh.
7. Giữ deploy cũ trong lịch sử Netlify để có thể rollback nếu cần.

LƯU Ý QUAN TRỌNG VỀ BOOKING VÀ QUẢN LÝ
- Hiện tại GOOGLE_SHEETS_WEB_APP_URL trong app.js để trống. Website chạy ở chế độ xem thử: booking lưu trong localStorage của trình duyệt khách gửi form. admin.html chỉ đọc dữ liệu demo trên cùng trình duyệt/thiết bị; không thể tự nhận booking từ điện thoại khách sang điện thoại chủ website.
- Để nhận booking tập trung từ mọi khách, cần tạo Google Sheet riêng, triển khai google-apps-script.gs thành Web App rồi dán URL vào GOOGLE_SHEETS_WEB_APP_URL trong app.js trước khi deploy.
- Apps Script hiện chỉ ghi booking vào Google Sheet; chủ website xem booking trực tiếp trong Google Sheet. Không bật quyền công khai bảng tính. Không đưa dữ liệu khách hàng lên nơi công khai.
- Trang admin.html hiện là dashboard demo, chưa có đăng nhập quản trị và không phải khu vực bảo mật. Không dùng nó để lưu hoặc hiển thị dữ liệu booking thật nhạy cảm khi chưa bổ sung xác thực phía máy chủ.

KẾT NỐI GOOGLE SHEETS (KHI SẴN SÀNG)
1. Tạo Google Sheet mới, đặt tên tab đầu tiên là Bookings.
2. Mở Extensions > Apps Script, dán toàn bộ mã trong google-apps-script.gs.
3. Deploy > New deployment > Web app; Execute as: Me. Quyền truy cập Web App cần được cấu hình phù hợp để khách gửi form được; chỉ chia sẻ file Google Sheet với tài khoản quản lý.
4. Sao chép URL Web App và thay giá trị GOOGLE_SHEETS_WEB_APP_URL ở đầu app.js.
5. Deploy lại website lên đúng site Netlify hiện tại.

TRƯỚC KHI CÔNG KHAI
- Kiểm tra link Instagram, giá, phụ thu reader và nội dung giới thiệu reader.
- Nội dung thế mạnh reader hiện là bản biên tập theo định hướng đã chốt; nên rà lại với từng reader để bảo đảm mô tả đúng thực tế.
- Thay phần giới thiệu feedback bằng phản hồi thật khi có sự đồng ý của khách hàng.
